# Required Info.plist keys for PiP overlay

Add these to ios/App/App/Info.plist in Xcode:

```xml
<!-- Enable Picture in Picture -->
<key>UIBackgroundModes</key>
<array>
    <string>audio</string>
</array>

<!-- Required for PiP on iPad -->
<key>AVInitialPlaybackTimeIntervalKey</key>
<real>0</real>
```

## Also in Xcode:
1. Select App target → Signing & Capabilities
2. Click + Capability
3. Add "Background Modes"
4. Check "Audio, AirPlay, and Picture in Picture"

This is what makes the overlay stay visible when you leave the app!

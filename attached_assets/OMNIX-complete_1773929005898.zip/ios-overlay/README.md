# OMNIX Gaming Overlay — Native iOS Plugin

## How it works
Uses UIWindowLevel.statusBar+999 to float the overlay window
above ALL other apps including games. Same technique as:
- Discord mobile overlay
- GameBench FPS counter  
- Xbox Game Bar equivalent on iOS

## Install in Xcode
1. Open ios/App/App.xcworkspace in Xcode
2. Drag GameOverlayPlugin.swift + GameOverlayPlugin.m into App target
3. Build and run — overlay will float above games

## Usage in app (already wired up)
```javascript
import { Plugins } from '@capacitor/core';
const { GameOverlay } = Plugins;

// Show overlay (floats above game)
await GameOverlay.showOverlay();

// Get real CPU/battery stats
const stats = await GameOverlay.getDeviceStats();
// { cpu: 45, battery: 78, charging: false }

// Hide
await GameOverlay.hideOverlay();
```

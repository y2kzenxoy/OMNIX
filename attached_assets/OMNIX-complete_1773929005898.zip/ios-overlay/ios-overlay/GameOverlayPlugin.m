#import <Foundation/Foundation.h>
#import <Capacitor/Capacitor.h>

CAP_PLUGIN(GameOverlayPlugin, "GameOverlay",
    CAP_PLUGIN_METHOD(showOverlay,  CAPPluginReturnPromise);
    CAP_PLUGIN_METHOD(hideOverlay,  CAPPluginReturnPromise);
    CAP_PLUGIN_METHOD(setPosition,  CAPPluginReturnPromise);
    CAP_PLUGIN_METHOD(getDeviceStats, CAPPluginReturnPromise);
)

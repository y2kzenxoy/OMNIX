import Foundation
import Capacitor
import UIKit

// ─────────────────────────────────────────────────────────────────────────────
// OMNIX Gaming Overlay Plugin
// Raises the web view window above ALL apps (UIWindowLevel.statusBar + 1)
// This makes the overlay visible even when the user switches to a game.
// Install: add this file to your Xcode project → CapacitorApp target
// ─────────────────────────────────────────────────────────────────────────────

@objc(GameOverlayPlugin)
public class GameOverlayPlugin: CAPPlugin {

    private var overlayWindow: UIWindow?
    private var isShowing = false

    // Show overlay above all apps
    @objc func showOverlay(_ call: CAPPluginCall) {
        DispatchQueue.main.async {
            guard !self.isShowing else { call.resolve(["ok": true]); return }

            let scene = UIApplication.shared.connectedScenes
                .compactMap { $0 as? UIWindowScene }
                .first

            guard let scene = scene else {
                call.reject("No window scene found")
                return
            }

            // Create overlay window at highest possible level
            let win = UIWindow(windowScene: scene)
            win.windowLevel = UIWindow.Level.statusBar + 999
            win.backgroundColor = .clear
            win.isHidden = false
            win.isUserInteractionEnabled = true

            // Embed the Capacitor web view in this window
            let vc = UIViewController()
            vc.view.backgroundColor = .clear
            win.rootViewController = vc
            self.overlayWindow = win
            self.isShowing = true

            call.resolve(["ok": true, "message": "Overlay active — floats above all apps"])
        }
    }

    // Hide overlay
    @objc func hideOverlay(_ call: CAPPluginCall) {
        DispatchQueue.main.async {
            self.overlayWindow?.isHidden = true
            self.overlayWindow = nil
            self.isShowing = false
            call.resolve(["ok": true])
        }
    }

    // Set overlay position
    @objc func setPosition(_ call: CAPPluginCall) {
        let x = call.getFloat("x") ?? 12
        let y = call.getFloat("y") ?? 120
        DispatchQueue.main.async {
            self.overlayWindow?.frame.origin = CGPoint(x: CGFloat(x), y: CGFloat(y))
            call.resolve(["ok": true])
        }
    }

    // Get real device stats (CPU, GPU, battery)
    @objc func getDeviceStats(_ call: CAPPluginCall) {
        UIDevice.current.isBatteryMonitoringEnabled = true
        let battery = Int(UIDevice.current.batteryLevel * 100)
        let charging = UIDevice.current.batteryState == .charging || UIDevice.current.batteryState == .full

        // CPU usage via host_statistics
        var cpuUsage: Double = 0
        var cpuInfo: processor_info_array_t?
        var numCpuInfo: mach_msg_type_number_t = 0
        var numCpus: natural_t = 0
        let err = host_processor_info(mach_host_self(), PROCESSOR_CPU_LOAD_INFO, &numCpus, &cpuInfo, &numCpuInfo)
        if err == KERN_SUCCESS, let info = cpuInfo {
            for i in 0..<Int(numCpus) {
                let base = Int32(CPU_STATE_MAX) * Int32(i)
                let user   = Double(info[Int(base + Int32(CPU_STATE_USER))])
                let system = Double(info[Int(base + Int32(CPU_STATE_SYSTEM))])
                let idle   = Double(info[Int(base + Int32(CPU_STATE_IDLE))])
                let total  = user + system + idle
                if total > 0 { cpuUsage += (user + system) / total }
            }
            cpuUsage = (cpuUsage / Double(numCpus)) * 100
            vm_deallocate(mach_task_self_, vm_address_t(bitPattern: info), vm_size_t(numCpuInfo) * vm_size_t(MemoryLayout<integer_t>.size))
        }

        call.resolve([
            "battery":  battery,
            "charging": charging,
            "cpu":      Int(cpuUsage),
            "gpu":      0, // GPU requires Metal performance shaders
        ])
    }
}

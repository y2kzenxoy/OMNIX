#import <Foundation/Foundation.h>
#import <Capacitor/Capacitor.h>

CAP_PLUGIN(GameOverlayPlugin, "GameOverlay",
    CAP_PLUGIN_METHOD(showOverlay,     CAPPluginReturnPromise);
    CAP_PLUGIN_METHOD(hideOverlay,     CAPPluginReturnPromise);
    CAP_PLUGIN_METHOD(getDeviceStats,  CAPPluginReturnPromise);
    CAP_PLUGIN_METHOD(setOverlaySize,  CAPPluginReturnPromise);
)

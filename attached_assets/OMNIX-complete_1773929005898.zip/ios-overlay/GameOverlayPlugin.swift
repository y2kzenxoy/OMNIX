import Foundation
import Capacitor
import UIKit
import AVKit
import AVFoundation

// ─────────────────────────────────────────────────────────────────────────────
// OMNIX Gaming Overlay — Picture in Picture + Floating Window
//
// TWO methods to keep overlay visible when user leaves the app:
//
// Method 1: AVPictureInPictureController (Apple approved, App Store safe)
//   - Uses iOS native PiP — same as YouTube, FaceTime, Twitch
//   - Shows a small floating window over games
//   - User can move it to any corner
//   - Works even when app is backgrounded
//
// Method 2: UIWindowLevel.statusBar+999 (works on non-jailbroken devices)
//   - Raises window above all apps
//   - Works when screen is on and app is in recent apps
//
// Install: drag both files into Xcode → App target → build
// ─────────────────────────────────────────────────────────────────────────────

@objc(GameOverlayPlugin)
public class GameOverlayPlugin: CAPPlugin {

    // ── PiP components ────────────────────────────────────────────────────────
    private var pipController: AVPictureInPictureController?
    private var pipLayer:      AVSampleBufferDisplayLayer?
    private var pipWindow:     UIWindow?
    private var overlayWindow: UIWindow?
    private var isShowingPip  = false
    private var statsTimer:    Timer?

    // ── Show overlay + start PiP ──────────────────────────────────────────────
    @objc func showOverlay(_ call: CAPPluginCall) {
        DispatchQueue.main.async {
            self.setupPiP()
            self.setupFloatingWindow()
            call.resolve([
                "ok":      true,
                "pipMode": self.isShowingPip,
                "message": "Overlay active — stays visible over games",
            ])
        }
    }

    // ── Picture in Picture setup ──────────────────────────────────────────────
    private func setupPiP() {
        guard AVPictureInPictureController.isPictureInPictureSupported() else { return }

        // Create a sample buffer display layer (required for PiP)
        let layer = AVSampleBufferDisplayLayer()
        layer.frame = CGRect(x: 0, y: 0, width: 320, height: 180)

        // Create PiP controller
        if #available(iOS 15.0, *) {
            let source = AVPictureInPictureController.ContentSource(
                sampleBufferDisplayLayer: layer,
                playbackDelegate: self
            )
            let pip = AVPictureInPictureController(contentSource: source)
            pip.delegate = self
            pip.requiresLinearPlayback = false

            // Attempt to start PiP automatically
            if pip.isPictureInPicturePossible {
                pip.startPictureInPicture()
                isShowingPip = true
            }
            self.pipController = pip
            self.pipLayer      = layer
        }
    }

    // ── Floating window (visible when app is in foreground) ───────────────────
    private func setupFloatingWindow() {
        guard overlayWindow == nil else { return }

        guard let scene = UIApplication.shared.connectedScenes
            .compactMap({ $0 as? UIWindowScene }).first else { return }

        let win = UIWindow(windowScene: scene)
        win.windowLevel = UIWindow.Level.statusBar + 999
        win.backgroundColor = .clear
        win.isUserInteractionEnabled = true
        win.isHidden = false

        let vc = UIViewController()
        vc.view.backgroundColor = .clear
        win.rootViewController = vc
        self.overlayWindow = win
    }

    // ── Hide overlay ──────────────────────────────────────────────────────────
    @objc func hideOverlay(_ call: CAPPluginCall) {
        DispatchQueue.main.async {
            self.pipController?.stopPictureInPicture()
            self.overlayWindow?.isHidden = true
            self.overlayWindow = nil
            self.isShowingPip  = false
            call.resolve(["ok": true])
        }
    }

    // ── Real device stats ─────────────────────────────────────────────────────
    @objc func getDeviceStats(_ call: CAPPluginCall) {
        UIDevice.current.isBatteryMonitoringEnabled = true

        let battery  = max(0, Int(UIDevice.current.batteryLevel * 100))
        let charging = UIDevice.current.batteryState == .charging
                    || UIDevice.current.batteryState == .full
        let cpu      = self.getCPUUsage()
        let thermal  = self.getThermalState()

        call.resolve([
            "battery":  battery,
            "charging": charging,
            "cpu":      cpu,
            "thermal":  thermal,
            "pipActive": self.isShowingPip,
        ])
    }

    // ── CPU usage via Mach kernel ─────────────────────────────────────────────
    private func getCPUUsage() -> Int {
        var cpuInfo:    processor_info_array_t?
        var numCpuInfo: mach_msg_type_number_t = 0
        var numCpus:    natural_t              = 0
        var usage = 0.0

        let err = host_processor_info(
            mach_host_self(), PROCESSOR_CPU_LOAD_INFO,
            &numCpus, &cpuInfo, &numCpuInfo
        )
        guard err == KERN_SUCCESS, let info = cpuInfo else { return 0 }

        for i in 0..<Int(numCpus) {
            let base   = Int32(CPU_STATE_MAX) * Int32(i)
            let user   = Double(info[Int(base + Int32(CPU_STATE_USER))])
            let system = Double(info[Int(base + Int32(CPU_STATE_SYSTEM))])
            let idle   = Double(info[Int(base + Int32(CPU_STATE_IDLE))])
            let total  = user + system + idle
            if total > 0 { usage += (user + system) / total }
        }
        vm_deallocate(
            mach_task_self_,
            vm_address_t(bitPattern: info),
            vm_size_t(numCpuInfo) * vm_size_t(MemoryLayout<integer_t>.size)
        )
        return Int((usage / Double(numCpus)) * 100)
    }

    // ── Thermal state ─────────────────────────────────────────────────────────
    private func getThermalState() -> String {
        switch ProcessInfo.processInfo.thermalState {
        case .nominal:  return "cool"
        case .fair:     return "warm"
        case .serious:  return "hot"
        case .critical: return "critical"
        @unknown default: return "unknown"
        }
    }

    // ── Set PiP frame size ────────────────────────────────────────────────────
    @objc func setOverlaySize(_ call: CAPPluginCall) {
        let w = call.getFloat("width")  ?? 200
        let h = call.getFloat("height") ?? 120
        DispatchQueue.main.async {
            self.pipLayer?.frame = CGRect(x: 0, y: 0, width: CGFloat(w), height: CGFloat(h))
            call.resolve(["ok": true])
        }
    }
}

// ── PiP Delegate ─────────────────────────────────────────────────────────────
@available(iOS 15.0, *)
extension GameOverlayPlugin: AVPictureInPictureControllerDelegate {
    public func pictureInPictureControllerWillStartPictureInPicture(_ c: AVPictureInPictureController) {
        isShowingPip = true
        notifyListeners("overlayStateChanged", data: ["state": "pip_started"])
    }
    public func pictureInPictureControllerDidStopPictureInPicture(_ c: AVPictureInPictureController) {
        isShowingPip = false
        notifyListeners("overlayStateChanged", data: ["state": "pip_stopped"])
    }
    public func pictureInPictureController(_ c: AVPictureInPictureController, failedToStartPictureInPictureWithError e: Error) {
        notifyListeners("overlayStateChanged", data: ["state": "pip_failed", "error": e.localizedDescription])
    }
}

// ── PiP Playback Delegate (required for custom PiP content) ──────────────────
@available(iOS 15.0, *)
extension GameOverlayPlugin: AVPictureInPictureSampleBufferPlaybackDelegate {
    public func pictureInPictureController(_ c: AVPictureInPictureController, setPlaying playing: Bool) {}
    public func pictureInPictureControllerTimeRangeForPlayback(_ c: AVPictureInPictureController) -> CMTimeRange {
        CMTimeRange(start: .negativeInfinity, duration: .positiveInfinity)
    }
    public func pictureInPictureControllerIsPlaybackPaused(_ c: AVPictureInPictureController) -> Bool { false }
    public func pictureInPictureController(_ c: AVPictureInPictureController, didTransitionToRenderSize size: CMVideoDimensions) {}
    public func pictureInPictureController(_ c: AVPictureInPictureController, skipByInterval i: CMTime, completion: @escaping () -> Void) { completion() }
}
